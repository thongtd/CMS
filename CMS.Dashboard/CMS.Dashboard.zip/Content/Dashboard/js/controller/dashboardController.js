﻿var app = angular.module('CMS', []);
app.controller('dashboard', function ($scope) {
    $scope.productImages = [5];

    $scope.initProductImages = function() {
        for (var i = 0; i < 5; i++) {
            
        }
    }
});